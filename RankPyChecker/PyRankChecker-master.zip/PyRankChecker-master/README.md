#PyRankChecker

PyRankChecker is a simple tool written in Python which helps to find out URL's position against a keyword on Google.

##Who can use it?

Anyone who is interested to know where his site standing against the keywords he is targeting for. Mainly it's helpful for bloggers, Internet marketers and SEO experts.

##Usage

From command line write the following command:

`python pyrc.py <Keyword> <URL>`

##System Requirements

You must have Python(2.7 or 3.x) installed on your machine.
